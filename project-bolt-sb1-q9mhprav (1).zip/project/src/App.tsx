import React, { useState } from 'react';
import { Heart, CheckCircle, Users, Calendar, DollarSign, Film } from 'lucide-react';

type Category = {
  id: string;
  icon: React.ElementType;
  title: string;
  description: string;
  features: string[];
};

const categories: Category[] = [
  {
    id: 'planning',
    icon: CheckCircle,
    title: 'Smart Planning',
    description: 'AI-powered planning tools',
    features: [
      'Personalized checklists',
      'Guided workflows',
      'Progress tracking',
      'Deadline management'
    ]
  },
  {
    id: 'family',
    icon: Users,
    title: 'Family Coordination',
    description: 'Keep everyone connected',
    features: [
      'Group messaging',
      'Task delegation',
      'Event scheduling',
      'Virtual participation'
    ]
  },
  {
    id: 'services',
    icon: Calendar,
    title: 'Service Booking',
    description: 'Streamlined vendor management',
    features: [
      'Vendor directory',
      'Direct booking',
      'Quote comparison',
      'Contract management'
    ]
  },
  {
    id: 'financial',
    icon: DollarSign,
    title: 'Financial Tools',
    description: 'Simplified payment solutions',
    features: [
      'Budget tracking',
      'Digital payments',
      'Expense sharing',
      'Crowdfunding options'
    ]
  },
  {
    id: 'memorial',
    icon: Heart,
    title: 'Memorial Features',
    description: 'Honor their memory',
    features: [
      'Digital tributes',
      'Photo collections',
      'Memory sharing',
      'Legacy preservation'
    ]
  },
  {
    id: 'virtual',
    icon: Film,
    title: 'Virtual Services',
    description: 'Connect from anywhere',
    features: [
      'Live streaming',
      'Recording options',
      'Virtual gatherings',
      'Digital guestbook'
    ]
  }
];

function CategoryCard({ category, isSelected, onClick }: { 
  category: Category; 
  isSelected: boolean;
  onClick: () => void;
}) {
  const Icon = category.icon;
  return (
    <div 
      className={`cursor-pointer p-4 rounded-xl transition-all duration-300 backdrop-blur-sm ${
        isSelected 
          ? 'bg-gradient-to-br from-earth-600 to-earth-700 text-cream-50 shadow-lg scale-102' 
          : 'bg-cream-50/80 hover:bg-cream-100/90 shadow-soft'
      }`}
      onClick={onClick}
    >
      <div className="flex items-center">
        <Icon className={`w-6 h-6 ${isSelected ? 'text-cream-100' : 'text-earth-600'}`} />
        <h3 className="font-semibold text-base ml-2">{category.title}</h3>
      </div>
      <p className={`text-sm mt-1 ${isSelected ? 'text-cream-50/90' : 'text-earth-600/80'}`}>
        {category.description}
      </p>
    </div>
  );
}

function App() {
  const [selectedCategory, setSelectedCategory] = useState<string>('planning');

  const selected = categories.find(c => c.id === selectedCategory);

  return (
    <div className="min-h-screen bg-gradient-to-br from-cream-50 via-sage-100 to-cream-100">
      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-light text-earth-700 mb-2 tracking-wide">
            Plan Your Peace
          </h1>
          <p className="text-earth-600/80 max-w-2xl mx-auto text-base font-light">
            Compassionate funeral planning that brings peace of mind to you and your loved ones.
          </p>
        </div>

        {/* Main Layout */}
        <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Categories Grid */}
          <div className="lg:col-span-1">
            <div className="grid grid-cols-2 lg:grid-cols-1 gap-3">
              {categories.map(category => (
                <CategoryCard
                  key={category.id}
                  category={category}
                  isSelected={selectedCategory === category.id}
                  onClick={() => setSelectedCategory(category.id)}
                />
              ))}
            </div>
          </div>

          {/* Selected Category Details */}
          <div className="lg:col-span-2">
            {selected && (
              <div className="bg-cream-50/80 backdrop-blur-sm rounded-xl p-6 shadow-soft h-full">
                <h2 className="text-xl font-light text-earth-700 mb-4 flex items-center">
                  <selected.icon className="w-6 h-6 text-earth-600 mr-2" />
                  {selected.title}
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {selected.features.map((feature, index) => (
                    <div key={index} className="flex items-center text-earth-600/90 bg-cream-100/50 rounded-lg p-3">
                      <CheckCircle className="w-5 h-5 text-sage-600 mr-2 flex-shrink-0" />
                      <span className="font-light">{feature}</span>
                    </div>
                  ))}
                </div>
                <div className="mt-6 text-center">
                  <button className="bg-gradient-to-r from-earth-600 to-earth-700 text-cream-50 px-8 py-3 rounded-full font-light tracking-wide hover:shadow-lg transition-all duration-300">
                    Begin Your Journey
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-cream-50/60 backdrop-blur-sm py-4 px-4 mt-8">
        <div className="max-w-4xl mx-auto text-center text-earth-600/70">
          <div className="space-x-6">
            <a href="#" className="hover:text-earth-700 transition-colors duration-200">Privacy</a>
            <a href="#" className="hover:text-earth-700 transition-colors duration-200">Terms</a>
            <a href="#" className="hover:text-earth-700 transition-colors duration-200">Support</a>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;