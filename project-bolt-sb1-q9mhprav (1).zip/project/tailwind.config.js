/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        cream: {
          50: '#FDFAF6',
          100: '#F5EFE6',
          200: '#EBE3D7'
        },
        sage: {
          50: '#F2F4F1',
          100: '#E3E7E1',
          200: '#D4DBD1',
          600: '#7C8B76'
        },
        earth: {
          100: '#E5DCD3',
          200: '#D3C4B6',
          600: '#967259',
          700: '#7D5E48'
        }
      },
      boxShadow: {
        'soft': '0 4px 20px -2px rgba(0, 0, 0, 0.06)',
        'inner-soft': 'inset 0 2px 4px 0 rgba(0, 0, 0, 0.03)',
      }
    },
  },
  plugins: [],
};